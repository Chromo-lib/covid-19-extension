<div align="center">
  <img src="dist/icons/icon128.png"><br /><br />
  <h1 style="margin:0">CovidNow</h1>
  <h4 style="margin-top:0">A Free And Lightweight</h4>
  <p>Covid19 Cases and Deaths by Country chrome extension</p>

  ![Contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen) ![GitHub release](https://img.shields.io/github/release/Chromo-lib/covid-19-extension/all?logo=GitHub) ![](https://badgen.net/github/license/Chromo-lib/covid-19-extension)

</div>

### Capture
![covid19](cov.PNG)

![covid19](covid-extension.PNG)

### License
MIT