<div align="center">
  <img src="dist/icons/icon128.png"><br /><br />
  <h1 style="margin:0">CovidNow</h1>
  <h4 style="margin-top:0">A Free And Lightweight</h4>
  <p>🦠 😷 browser extension for Tracking coronavirus global spread 🔬🌡</p>

  ![Contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen) ![GitHub release](https://img.shields.io/github/release/Chromo-lib/covid-19-extension/all?logo=GitHub) ![](https://badgen.net/github/license/Chromo-lib/covid-19-extension) [![Firefox](https://img.shields.io/amo/v/covidnow?label=firefox&style=flat-square)](https://addons.mozilla.org/firefox/addon/covidnow)

</div>

## Installation
- [Firefox](https://addons.mozilla.org/firefox/addon/covidnow)
- [Edge Chromium](https://microsoftedge.microsoft.com/addons/detail/covidnow/ndohbioafkjajehnnkhflkmkmoakakda)

### Captures
![covid19](cov.png)

![covid19](cov2.png)

### License
MIT